export class CreateSwimlaneDto {
  name: string;
  order: number;
  boardId: number;
}
